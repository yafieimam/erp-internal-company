<header class="head ">
  <div class="prelative container cont-header mx-auto wow fadeInDown">
    <div class="tops_nheaders mx-auto">
      <div class="row">
        <div class="col-md-30"></div>
        <div class="col-md-30 text-right">
            <div class="box-telp">
                <p>
                  <a href="#"><span><img src="{{asset('app-assets/asset/images/phone-white.png')}}" alt=""></span> 031-8913030</a>
                </p>
            </div>
            <?php
            if(Session::get('login')){
              if(Session::get('tipe_user') == 1 || Session::get('tipe_user') == 2 || Session::get('tipe_user') == 3){
            ?>
            <div class="login">
                <a href="{{ url('profile') }}">
                    <p>HELLO, {{ strtoupper(Session::get('email')) }}</p>
                </a>
            </div>

            <div class="login">
                <a href="{{ url('/logoutEn') }}">
                    <p>LOG OUT</p>
                </a>
            </div>
            <?php
              }else{
            ?>
            <div class="login">
                <a href="{{ url('en/contact') }}">
                    <p>CONTACT</p>
                </a>
            </div>

            <div class="login">
                <a href="{{ url('en/profile') }}">
                    <p>HELLO, {{ strtoupper(Session::get('name')) }}</p>
                </a>
            </div>

            <div class="login">
                <a href="{{ url('/logoutEn') }}">
                    <p>LOG OUT</p>
                </a>
            </div>

            @yield('nav')

            <?php
              }
            ?>
            
            <?php
            }else{
            ?>
            <div class="login">
                <a href="{{ url('en/contact') }}">
                    <p>CONTACT</p>
                </a>
            </div>

            <div class="login">
                <a href="{{ url('en/login') }}" data-toggle="tooltip" title="Login to enter the web">
                    <p>LOG IN</p>
                </a>
                <!-- <span class="tiploginen">Login to enter the web</span> -->
            </div>

            <div class="login">
                <a href="{{ url('en/register') }}" data-toggle="tooltip" title="Register to create new account">
                    <p>SIGN UP</p>
                </a>
                <!-- <span class="tipregisteren">Register to create new account</span> -->
            </div>

            @yield('nav')
            <?php
            }
            ?>

        </div>
      </div>
      <div class="clear clearfix"></div>
    </div>
    <div class="bottoms_nheaders">
      <div class="row">
        <div class="col-md-30">
            <div class="logo-header">
                <div class="logo">
                    <a href="{{ url('en') }}">
                      <img src="{{asset('app-assets/asset/images/logo-header.png')}}" alt="" class="img img-fluid">
                    </a>
                </div>
                <div class="lines-nmiddle mx-3"></div>
                <div class="ind-man">
                    <p>INDONESIA MANUFACTURING FACTORY OF <br><span>CALCIUM CARBONATE</span></p>
                </div>
                <div class="since"><img src="{{asset('app-assets/asset/images/since.png')}}" alt=""></div>
            </div>
        </div>
        <div class="col-md-30">
          <div class="menu-block-bottom text-right cmenubot">
            <ul class="list-inline text-right">
              <?php
              if(Session::get('login')){
                if(Session::get('tipe_user') == 1){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_admin') }}">Home</a></li>
              <li class="list-inline-item"><a href="{{ url('sales_admin') }}">Sales</a></li>
              <li class="list-inline-item"><a href="{{ url('produksi_admin') }}">Produksi</a></li>
              <li class="list-inline-item"><a href="{{ url('complaint_admin') }}">Complaint</a></li>
              <?php
                }else if(Session::get('tipe_user') == 2){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_sales') }}">Home</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">Input Data <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('input_omset_sales') }}">Omset Sales</a>
                <div class="subdropdown"><a href="{{ url('#') }}">Complaint <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('input_complaint_produksi') }}">Complaint Produksi</a>
                  <a href="{{ url('input_complaint_logistik') }}">Complaint Logistik</a>
                  <a href="{{ url('input_complaint_lainnya') }}">Complaint Lainnya</a>
                </div>
                </div>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">View Data <i class="fa fa-caret-down"></i></a>
              </li>
              <div class="dropdown-content">
                <a href="{{ url('view_omset_sales') }}">Omset Sales</a>
                <div class="subdropdown"><a href="{{ url('#') }}">Complaint <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('view_complaint_produksi') }}">Complaint Produksi</a>
                  <a href="{{ url('view_complaint_logistik') }}">Complaint Logistik</a>
                  <a href="{{ url('view_complaint_lainnya') }}">Complaint Lainnya</a>
                </div>
                </div>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="{{ url('validasi_sales') }}">Validasi Data <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content" style="right: 10%;">
                <div class="subdropdown"><a href="{{ url('#') }}">Complaint <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('validation_complaint_produksi') }}">Complaint Produksi</a>
                  <a href="{{ url('validation_complaint_logistik') }}">Complaint Logistik</a>
                  <a href="{{ url('validation_complaint_lainnya') }}">Complaint Lainnya</a>
                </div>
                </div>
              </div>
              </div>
              <?php
                }else if(Session::get('tipe_user') == 3){
              ?>
              <style type="text/css">
                .dropdown:hover .dropdown-content,  .dropdown:active .dropdown-content{
                  right: 10%;
                }
              </style>
              <li class="list-inline-item"><a href="{{ url('home_produksi') }}">Home</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">Input Data <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('input_omset_produksi') }}">Omset Produksi</a>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">View Data <i class="fa fa-caret-down"></i></a>
              </li>
              <div class="dropdown-content" >
                <a href="{{ url('view_omset_produksi') }}">Omset Produksi</a>
              </div>
              </div>
              <?php
                }else{
              ?>
              <li class="list-inline-item"><a href="{{ url('en') }}">Home</a></li>
              <li class="list-inline-item"><a href="{{ url('en/about') }}">About Us</a></li>
              <li class="list-inline-item"><a href="{{ url('en/products') }}">Products</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">Orders <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('en/form_complaint') }}">Form Complaint</a>
              </div>
              </div>
              <li class="list-inline-item"><a href="{{ url('en/quality') }}">Quality</a></li>
              <!-- <li class="list-inline-item"><a href="/en/home/news">Events</a></li> -->
              <li class="list-inline-item"><a href="{{ url('en/career') }}">Career</a></li>
              <?php
                } 
              }else{
              ?>
              <li class="list-inline-item"><a href="{{ url('en') }}">Home</a></li>
              <li class="list-inline-item"><a href="{{ url('en/about') }}">About Us</a></li>
              <li class="list-inline-item"><a href="{{ url('en/products') }}">Products</a></li>
              <li class="list-inline-item"><a href="{{ url('en/orders') }}">Orders</a></li>
              <li class="list-inline-item"><a href="{{ url('en/quality') }}">Quality</a></li>
              <!-- <li class="list-inline-item"><a href="/en/home/news">Events</a></li> -->
              <li class="list-inline-item"><a href="{{ url('en/career') }}">Career</a></li>
              <?php
              }
              ?>
            </ul>
          </div>
        </div>
      </div>
      <div class="clear clearfix"></div>
    </div>
    <!-- End inners head -->
  </div>
</header>

<section id="myAffix" class="header-affixs affix-top">
  <!-- <div class="clear height-15"></div> -->
  <div class="prelative container cont-header mx-auto">
    <div class="row">
      <div class="col-md-15 col-sm-15">
        <div class="lgo_web_headrs_wb">
          <a href="{{ url('en') }}">
            <img src="{{asset('app-assets/asset/images/logo-header-sticky.png')}}" alt="" class="img img-fluid">
          </a>
        </div>
      </div>
      <div class="col-md-45 col-sm-45">
        <div class="text-right"> 
          <div class="menu-taffix">
            <ul class="list-inline d-inline">
              <?php
              if(Session::get('login')){
                if(Session::get('tipe_user') == 1){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_admin') }}">HOME</a></li>
              <li class="list-inline-item"><a href="{{ url('sales_admin') }}">SALES</a></li>
              <li class="list-inline-item"><a href="{{ url('produksi_admin') }}">PRODUKSI</a></li>
              <li class="list-inline-item"><a href="{{ url('complaint_admin') }}">COMPLAINT</a></li>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }else if(Session::get('tipe_user') == 2){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_sales') }}">HOME</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">INPUT DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('input_omset_sales') }}">OMSET SALES</a>
                <div class="subdropdown"><a href="{{ url('#') }}">COMPLAINT <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('input_complaint_produksi') }}">COMPLAINT PRODUKSI</a>
                  <a href="{{ url('input_complaint_logistik') }}">COMPLAINT LOGISTIK</a>
                  <a href="{{ url('input_complaint_lainnya') }}">COMPLAINT LAINNYA</a>
                </div>
                </div>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">VIEW DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('view_omset_sales') }}">OMSET SALES</a>
                <div class="subdropdown"><a href="{{ url('#') }}">COMPLAINT <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('view_complaint_produksi') }}">COMPLAINT PRODUKSI</a>
                  <a href="{{ url('view_complaint_logistik') }}">COMPLAINT LOGISTIK</a>
                  <a href="{{ url('view_complaint_lainnya') }}">COMPLAINT LAINNYA</a>
                </div>
                </div>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">VALIDASI DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <div class="subdropdown"><a href="{{ url('#') }}">COMPLAINT <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('validation_complaint_produksi') }}">COMPLAINT PRODUKSI</a>
                  <a href="{{ url('validation_complaint_logistik') }}">COMPLAINT LOGISTIK</a>
                  <a href="{{ url('validation_complaint_lainnya') }}">COMPLAINT LAINNYA</a>
                </div>
                </div>
              </div>
              </div>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }else if(Session::get('tipe_user') == 3){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_produksi') }}">HOME</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">INPUT DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('input_omset_produksi') }}">OMSET PRODUKSI</a>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">VIEW DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('view_omset_produksi') }}">OMSET PRODUKSI</a>
              </div>
              </div>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }else{
              ?>
              <li class="list-inline-item"><a href="{{ url('en') }}">HOME</a></li>
              <li class="list-inline-item"><a href="{{ url('en/about') }}">ABOUT US</a></li>
              <li class="list-inline-item"><a href="{{ url('en/products') }}">PRODUCTS</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">ORDERS <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('en/form_complaint') }}">FORM COMPLAINT</a>
              </div>
              </div>
              <li class="list-inline-item"><a href="{{ url('en/quality') }}">QUALITY</a></li>
              <!-- <li class="list-inline-item"><a href="/en/home/news">EVENTS</a></li> -->
              <li class="list-inline-item"><a href="{{ url('en/career') }}">CAREER</a></li>
              <li class="list-inline-item"><a href="{{ url('en/contact') }}">CONTACT</a></li>
              <li class="list-inline-item"><a href="{{ url('en/profile') }}">PROFILE</a></li>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }
              }else{
              ?>
              <li class="list-inline-item"><a href="{{ url('en') }}">HOME</a></li>
              <li class="list-inline-item"><a href="{{ url('en/about') }}">ABOUT US</a></li>
              <li class="list-inline-item"><a href="{{ url('en/products') }}">PRODUCTS</a></li>
              <li class="list-inline-item"><a href="{{ url('en/orders') }}">ORDERS</a></li>
              <li class="list-inline-item"><a href="{{ url('en/quality') }}">QUALITY</a></li>
              <!-- <li class="list-inline-item"><a href="/en/home/news">EVENTS</a></li> -->
              <li class="list-inline-item"><a href="{{ url('en/career') }}">CAREER</a></li>
              <li class="list-inline-item"><a href="{{ url('en/contact') }}">CONTACT</a></li>
              <li class="list-inline-item"><a href="{{ url('en/login') }}" data-toggle="tooltip" title="Login to enter the web">LOG IN</a></li>
              <li class="list-inline-item"><a href="{{ url('en/register') }}" data-toggle="tooltip" title="Register to create new account">SIGN UP</a></li>
              <?php
              }
              ?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="clear"></div>
  </div>
</section>

<header class="header-mobile homepage_head">
  <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
  <a class="navbar-brand" href="{{ url('en') }}"><img src="{{asset('app-assets/asset/images/logo-header.png')}}" alt="" class="img img-fluid"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
            <?php
              if(Session::get('login')){
                if(Session::get('tipe_user') == 1){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_admin') }}">HOME</a></li>
              <li class="list-inline-item"><a href="{{ url('sales_admin') }}">SALES</a></li>
              <li class="list-inline-item"><a href="{{ url('produksi_admin') }}">PRODUKSI</a></li>
              <li class="list-inline-item"><a href="{{ url('complaint_admin') }}">COMPLAINT</a></li>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }else if(Session::get('tipe_user') == 2){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_sales') }}">HOME</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">INPUT DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('input_omset_sales') }}">OMSET SALES</a>
                <div class="subdropdown"><a href="{{ url('#') }}">COMPLAINT <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('input_complaint_produksi') }}">COMPLAINT PRODUKSI</a>
                  <a href="{{ url('input_complaint_logistik') }}">COMPLAINT LOGISTIK</a>
                  <a href="{{ url('input_complaint_lainnya') }}">COMPLAINT LAINNYA</a>
                </div>
                </div>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">VIEW DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('view_omset_sales') }}">OMSET SALES</a>
                <div class="subdropdown"><a href="{{ url('#') }}">COMPLAINT <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('view_complaint_produksi') }}">COMPLAINT PRODUKSI</a>
                  <a href="{{ url('view_complaint_logistik') }}">COMPLAINT LOGISTIK</a>
                  <a href="{{ url('view_complaint_lainnya') }}">COMPLAINT LAINNYA</a>
                </div>
                </div>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">VALIDASI DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <div class="subdropdown"><a href="{{ url('#') }}">COMPLAINT <i class="fa fa-caret-right"></i></a>
                <div class="dropdown-subcontent">
                  <a href="{{ url('validation_complaint_produksi') }}">COMPLAINT PRODUKSI</a>
                  <a href="{{ url('validation_complaint_logistik') }}">COMPLAINT LOGISTIK</a>
                  <a href="{{ url('validation_complaint_lainnya') }}">COMPLAINT LAINNYA</a>
                </div>
                </div>
              </div>
              </div>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }else if(Session::get('tipe_user') == 3){
              ?>
              <li class="list-inline-item"><a href="{{ url('home_produksi') }}">HOME</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">INPUT DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('input_omset_produksi') }}">OMSET PRODUKSI</a>
              </div>
              </div>
              <div class="dropdown"><li class="list-inline-item"><a href="#">VIEW DATA <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('view_omset_produksi') }}">OMSET PRODUKSI</a>
              </div>
              </div>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }else{
              ?>
              <li class="list-inline-item"><a href="{{ url('en') }}">HOME</a></li>
              <li class="list-inline-item"><a href="{{ url('en/about') }}">ABOUT US</a></li>
              <li class="list-inline-item"><a href="{{ url('en/products') }}">PRODUCTS</a></li>
              <div class="dropdown"><li class="list-inline-item"><a href="#">ORDERS <i class="fa fa-caret-down"></i></a></li>
              <div class="dropdown-content">
                <a href="{{ url('en/form_complaint') }}">FORM COMPLAINT</a>
              </div>
              </div>
              <li class="list-inline-item"><a href="{{ url('en/quality') }}">QUALITY</a></li>
              <!-- <li class="list-inline-item"><a href="/en/home/news">EVENTS</a></li> -->
              <li class="list-inline-item"><a href="{{ url('en/career') }}">CAREER</a></li>
              <li class="list-inline-item"><a href="{{ url('en/contact') }}">CONTACT</a></li>
              <li class="list-inline-item"><a href="{{ url('en/profile') }}">PROFILE</a></li>
              <li class="list-inline-item"><a href="{{ url('/logoutEn') }}">LOG OUT</a></li>
              <?php
                }
              }else{
              ?>
              <li class="list-inline-item"><a href="{{ url('en') }}">HOME</a></li>
              <li class="list-inline-item"><a href="{{ url('en/about') }}">ABOUT US</a></li>
              <li class="list-inline-item"><a href="{{ url('en/products') }}">PRODUCTS</a></li>
              <li class="list-inline-item"><a href="{{ url('en/orders') }}">ORDERS</a></li>
              <li class="list-inline-item"><a href="{{ url('en/quality') }}">QUALITY</a></li>
              <!-- <li class="list-inline-item"><a href="/en/home/news">EVENTS</a></li> -->
              <li class="list-inline-item"><a href="{{ url('en/career') }}">CAREER</a></li>
              <li class="list-inline-item"><a href="{{ url('en/contact') }}">CONTACT</a></li>
              <li class="list-inline-item"><a href="{{ url('en/login') }}" data-toggle="tooltip" title="Login to enter the web">LOG IN</a></li>
              <li class="list-inline-item"><a href="{{ url('en/register') }}" data-toggle="tooltip" title="Register to create new account">SIGN UP</a></li>
              <?php
              }
              ?>
        @yield('nav_footer')
    </ul>
  </div>
  </nav>
</header>