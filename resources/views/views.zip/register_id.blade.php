@extends('layouts.app_id')

@section('title')
<title>DAFTAR - PT. DWI SELO GIRI MAS</title>
@endsection

@section('css_login')
  <link rel="stylesheet" href="{{asset('app-assets/fonts/material-icon/css/material-design-iconic-font.min.css')}}">
  <link rel="stylesheet" href="{{asset('app-assets/css/style.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('app-assets/css/util.css')}}">
@endsection

@section('nav')
            <div class="bahasa">
                <p>
                  <a href="{{ url('en/register') }}"><span class="">EN</span></a>
                  &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
                  <a href="{{ url('id/register') }}"><span class="active">IN</span></a>
                </p>
            </div>
@endsection

@section('nav_footer')
      <li class="nav-item">
            <a class="bahasa-mobile" href="{{ url('en/register') }}" title="ENG">English&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;</a>
            <a class="bahasa-mobile ind" href="{{ url('id/register') }}" title="Bahasa">Indonesia</a>
      </li>
@endsection

@section('content')
<div class="main">

        <div class="container">
            <div class="signup-content">
                <div class="signup-form p-t-50">
                    <span class="login100-form-title wow fadeInDown">Daftar</span>
                      @if ($errors->any())
                        <div class="alert alert-danger" style="width: 40%; margin-left: 30%; margin-top: 20px;">
                          <ul>
                            @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                      @endif
                    <form method="post" class="register-form" id="register-form">
                      {{ csrf_field() }}
                        <div class="form-row">
                            <div class="form-group">
                                <div class="form-input validate-input wow fadeInDown" data-validate = "Email harus diisi / Format Email salah">
                                    <label for="email" class="required">Email</label>
                                    <input class="input-baru" type="text" name="email" id="email" placeholder="Email" value="{{ Session::get('email') }}" />
                                </div>
                                <div class="form-select validate-input wow fadeInUp" data-validate = "Tipe Customer harus diisi">
                                    <div class="label-flex">
                                        <label for="tipe_user" class="required">Tipe Pelanggan</label>
                                    </div>
                                    <div class="select-list" style="margin-bottom: 0px;">
                                        <select class="dropdown-baru" name="tipe_user" id="tipe_user">
                                            <option class="tipeName" value="" selected>Tipe Pelanggan</option>
                                            <option class="tipeName" value="4">Agen</option>
                                            <option class="tipeName" value="5">Toko</option>
                                            <option class="tipeName" value="6">Personal / Perusahaan</option>
                                        </select>
                                    </div>
                                </div>
                                
                            </div>
                            <div class="form-group">
                                <div class="form-input validate-input wow fadeInDown" data-validate = "Password harus diisi">
                                    <label for="password" class="required">Password</label>
                                    <input class="input-baru" type="password" name="password" id="password" placeholder="Password" />
                                </div>
                                <div class="form-input validate-input wow fadeInUp" data-validate = "Konfirmasi Password harus diisi">
                                    <label for="confirm_pass" class="required">Konfirmasi Password</label>
                                    <input class="input-baru" type="password" name="confirm_pass" id="confirm_pass" placeholder="Konfirmasi Password" />
                                </div>
                            </div>
                          </div>
                        <div class="form-submit wow fadeInUp">
                            <div class="form-row" style="margin-left: 0px;">Sudah punya akun? <a href="{{ url('id/login') }}">&nbspMasuk disini</a></div>
                            <input type="submit" value="Daftar" class="submit" id="submit" name="submit" onclick="javascript: form.action='{{ url('/registerPostId') }}';" />
                            <input type="reset" value="Reset" class="submit" id="reset" name="reset" />
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
@endsection

@section('footer-script')
<!-- All JS -->
<script type="text/javascript">
    var baseurl = "{{ url('/id/register') }}";
    var url_add_cart_action = "/product/addCart";
    var url_edit_cart_action = "/product/edit";
</script>
@endsection

@section('script_login')
  <script src="{{asset('app-assets/vendor/select2/select2.min.js')}}"></script>
  <script src="{{asset('app-assets/js/main.js')}}"></script>

    <!-- <script type="text/javascript">
      $('.itemName').select2({
        placeholder: 'Nama',
        allowClear: true,
        ajax: {
          url: '/autocomplete',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results:  $.map(data, function (item) {
                    return {
                        text: item.custname,
                        id: item.id_customer
                    }
                })
            };
          },
          cache: true
        }
      });
  </script>

  <script type="text/javascript">
    $(document).ready(function(){ 
      $(function(){
          $('#itemName').change(function(){
             var opt = $(this).val();
              if(opt){
                  $('#submit1').hide();
                  $('#submit2').show();
              }else{
                  $('#submit1').show();
                  $('#submit2').hide();
              }
          });
      });
    });
  </script>

  <script type="text/javascript">
    $(".resetButton").on("click","#reset", function(){
      $(".itemName").val('').trigger('change');
    });
  </script>

  <script type="text/javascript">
    $(".itemName").on("select2:open", function() {
        $(".select2-search__field").attr("placeholder", "Cari Nama Disini...");
    });
    $(".itemName").on("select2:close", function() {
        $(".select2-search__field").attr("placeholder", null);
    });
  </script> -->
@endsection